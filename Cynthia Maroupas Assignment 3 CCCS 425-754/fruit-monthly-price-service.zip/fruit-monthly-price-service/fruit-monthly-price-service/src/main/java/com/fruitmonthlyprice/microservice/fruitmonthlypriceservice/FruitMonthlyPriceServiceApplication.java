//Student Name : Cynthia Maroupas Student ID: 261119382

package com.fruitmonthlyprice.microservice.fruitmonthlypriceservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FruitMonthlyPriceServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FruitMonthlyPriceServiceApplication.class, args);
	}

}
