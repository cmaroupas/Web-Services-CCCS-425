//Student Name : Cynthia Maroupas Student ID: 261119382

package com.fruitmonthlyprice.microservice.fruitmonthlypriceservice;

import java.io.IOException;
import java.text.DecimalFormat;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
public class FruitMonthlyPriceController {

    // Injecting the path to the Excel file from the application.properties file
    @Value("${fmp.file.path}")
    private String fmpFilePath;

    // Mapping to the REST endpoint that accepts fruit and month as path variables and returns a FruitMonthlyPrice object
    @GetMapping("/fruit-month-price/fruit/{fruit}/month/{month}")
    public FruitMonthlyPrice getFruitMonthlyPrice(@PathVariable String fruit, @PathVariable String month) throws IOException {
        
        // Opening the Excel workbook
        Workbook workbook = new XSSFWorkbook(new ClassPathResource(fmpFilePath).getInputStream());
        
        // Selecting the first sheet in the workbook
        Sheet sheet = workbook.getSheetAt(0);
        
        FruitMonthlyPrice fruitMonthlyPrice = null;
        int fruitRowNum = -1;
        int monthColNum = -1;
        
        // Looping through all the rows and columns in the sheet to find the matching fruit and month
        for (Row row : sheet) {
            for (Cell cell : row) {
                if (cell.getCellType() == CellType.STRING && cell.getStringCellValue().equalsIgnoreCase(fruit)) {
                    fruitRowNum = row.getRowNum();
                } else if (cell.getCellType() == CellType.STRING && cell.getStringCellValue().equalsIgnoreCase(month)) {
                    monthColNum = cell.getColumnIndex();
                }
                
                // Break out of both loops if both row and column have been found
                if (fruitRowNum != -1 && monthColNum != -1) {
                    break;
                }
            }
            
            // Break out of the outer loop if both row and column have been found
            if (fruitRowNum != -1 && monthColNum != -1) {
                break;
            }
        }
        
        // Throw a 404 error if the fruit-month combination is not found
        if (fruitRowNum == -1 || monthColNum == -1) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Fruit-month combination not found");
        }
        
        // Retrieve the matching row and column to get the fruit monthly price
        Row fruitRow = sheet.getRow(fruitRowNum);
        double fmp = fruitRow.getCell(monthColNum).getNumericCellValue();
        
        // Format the price to two decimal places
        DecimalFormat df = new DecimalFormat("#.##");
        fmp = Double.parseDouble(df.format(fmp));
        
        // Create and return a new FruitMonthlyPrice object with the matching fruit, month, and price
        fruitMonthlyPrice = new FruitMonthlyPrice(
                null, // set id to null because we don't have an id yet
                fruit,
                month,
                fmp,
                "8000"); // set environment to 8000 because we're assuming it's being run on port 8000
        return fruitMonthlyPrice;
    }
}