//Student Name : Cynthia Maroupas Student ID: 261119382

package com.fruitmonthlyprice.microservice.fruitmonthlypriceservice;

/**
 * Represents the monthly price of a specific fruit.
 */
public class FruitMonthlyPrice {
	
    // The unique identifier of this fruit monthly price.
    private Long id;

    // The name of the fruit.
    private String fruit;

    // The month of the year that this price corresponds to.
    private String month;

    // The price of the fruit for the given month.
    private Double fmp;

    // The environment (port) in which this price was recorded.
    private String environment;

    /**
     * Default constructor.
     */
    public FruitMonthlyPrice() {
    }

    /**
     * Constructs a new FruitMonthlyPrice with the given values.
     *
     * @param id          the unique identifier of this fruit monthly price
     * @param fruit       the name of the fruit
     * @param month       the month of the year that this price corresponds to
     * @param fmp         the price of the fruit for the given month
     * @param environment the environment in which this price was recorded
     */
    public FruitMonthlyPrice(Long id, String fruit, String month, Double fmp, String environment) {
        this.id = id;
        this.fruit = fruit;
        this.month = month;
        this.fmp = fmp;
        this.environment = environment;
    }

    /**
     * Returns the unique identifier of this fruit monthly price.
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the unique identifier of this fruit monthly price.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Returns the name of the fruit.
     */
    public String getFruit() {
        return fruit;
    }

    /**
     * Sets the name of the fruit.
     */
    public void setFruit(String fruit) {
        this.fruit = fruit;
    }

    /**
     * Returns the month of the year that this price corresponds to.
     */
    public String getMonth() {
        return month;
    }

    /**
     * Sets the month of the year that this price corresponds to.
     */
    public void setMonth(String month) {
        this.month = month;
    }

    /**
     * Returns the price of the fruit for the given month.
     */
    public Double getFmp() {
        return fmp;
    }

    /**
     * Sets the price of the fruit for the given month.
     */
    public void setFmp(Double fmp) {
        this.fmp = fmp;
    }

    /**
     * Returns the environment in which this price was recorded.
     */
    public String getEnvironment() {
        return environment;
    }

    /**
     * Sets the environment in which this price was recorded.
     */
    public void setEnvironment(String environment) {
        this.environment = environment;
    }
}
