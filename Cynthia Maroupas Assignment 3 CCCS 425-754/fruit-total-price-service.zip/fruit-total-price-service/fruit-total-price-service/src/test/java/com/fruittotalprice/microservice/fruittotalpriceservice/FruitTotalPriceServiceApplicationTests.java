package com.fruittotalprice.microservice.fruittotalpriceservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruitTotalPriceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
