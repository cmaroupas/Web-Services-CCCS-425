//Student Name : Cynthia Maroupas Student ID: 261119382

package com.fruittotalprice.microservice.fruittotalpriceservice;

public class FruitTotalPrice {

	private Long id;
	private String fruit;
	private String month;
	private Double fmp;
	private Integer quantity;
	private Double totalPrice;
	private String environment;

	public FruitTotalPrice() {
	}

	public FruitTotalPrice(Long id, String fruit, String month, Double fmp, Integer quantity, String environment) {
		super();
		this.id = id;
		this.fruit = fruit;
		this.month = month;
		this.fmp = fmp;
		this.quantity = quantity;
		this.totalPrice = fmp * quantity;
		this.environment = environment;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFruit() {
		return fruit;
	}

	public void setFruit(String fruit) {
		this.fruit = fruit;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public Double getFmp() {
		return fmp;
	}

	public void setFmp(Double fmp) {
		this.fmp = fmp;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = Double.parseDouble(String.format("%.2f", totalPrice));
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

}