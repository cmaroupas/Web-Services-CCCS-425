//Student Name : Cynthia Maroupas Student ID: 261119382

package com.fruittotalprice.microservice.fruittotalpriceservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@RestController
@RequestMapping("/fruit-total-price")
public class FruitTotalPriceController {

    private final FruitTotalPriceService fruitTotalPriceService;

    public FruitTotalPriceController(FruitTotalPriceService fruitTotalPriceService) {
        this.fruitTotalPriceService = fruitTotalPriceService;
    }

    @GetMapping("/fruit/{fruit}/month/{month}/quantity/{quantity}")
    public ResponseEntity<FruitTotalPrice> getFruitTotalPrice(
        @PathVariable String fruit,
        @PathVariable String month,
        @PathVariable Integer quantity
    ) {
        FruitTotalPrice fruitTotalPrice = fruitTotalPriceService.calculateFruitTotalPrice(fruit, month, quantity);
        return ResponseEntity.ok(fruitTotalPrice);
    }

}