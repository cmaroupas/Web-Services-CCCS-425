//Student Name : Cynthia Maroupas Student ID: 261119382

package com.fruittotalprice.microservice.fruittotalpriceservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class FruitTotalPriceServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FruitTotalPriceServiceApplication.class, args);
	}
	
	  @Bean
	    public RestTemplate restTemplate() {
	        return new RestTemplate();
	    }

}
