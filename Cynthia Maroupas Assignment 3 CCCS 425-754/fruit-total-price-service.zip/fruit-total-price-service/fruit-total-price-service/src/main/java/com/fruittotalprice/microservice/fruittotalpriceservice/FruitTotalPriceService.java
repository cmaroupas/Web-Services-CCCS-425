//Student Name : Cynthia Maroupas Student ID: 261119382

package com.fruittotalprice.microservice.fruittotalpriceservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fruitmonthlyprice.microservice.fruitmonthlypriceservice.FruitMonthlyPrice;

@Service
public class FruitTotalPriceService {

	@Autowired
	private RestTemplate restTemplate;

	/**
	 * Calculates the total price of a given fruit for a given month and quantity. 
	 * @param fruit the name of the fruit
	 * @param month the month of the price
	 * @param quantity the quantity of the fruit
	 * @return a FruitTotalPrice object containing the fruit name, month, monthly price, quantity, total price, and environment
	 */
	public FruitTotalPrice calculateFruitTotalPrice(String fruit, String month, Integer quantity) {

		String url = "http://localhost:8000/fruit-month-price/fruit/{fruit}/month/{month}";
		//HTTP request
	    ResponseEntity<FruitMonthlyPrice> response = restTemplate.getForEntity(url, FruitMonthlyPrice.class, fruit, month);
	    Double fmp = response.getBody().getFmp();

	    // Calculate total price
	    Double totalPrice = fmp * quantity;

	    // Create FruitTotalPrice object
	    FruitTotalPrice fruitTotalPrice = new FruitTotalPrice();
	    fruitTotalPrice.setFruit(fruit);
	    fruitTotalPrice.setMonth(month);
	    fruitTotalPrice.setFmp(fmp);
	    fruitTotalPrice.setQuantity(quantity);
	    fruitTotalPrice.setTotalPrice(totalPrice);
	    fruitTotalPrice.setEnvironment("8000");

	    return fruitTotalPrice;
	}
	}